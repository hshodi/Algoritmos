package ado;

public interface Prioridade{
    public boolean autentica(String senha);
}