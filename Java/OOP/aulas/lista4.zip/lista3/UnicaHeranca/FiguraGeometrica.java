package HerancaUnica;

public class FiguraGeometrica{

    double perimetro;
    double area;

    public void print_values(){
        System.out.println("Area: " + this.area);
        System.out.println("Perimetro: " + this.perimetro);
    }

}