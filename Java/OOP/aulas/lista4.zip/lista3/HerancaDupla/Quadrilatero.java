package HerancaDupla;

public class Quadrilatero extends FiguraGeometrica{

    double base;
    double altura;

}